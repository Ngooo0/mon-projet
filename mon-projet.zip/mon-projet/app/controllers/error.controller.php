<?php
// Gestion des erreurs